import React from 'react';

const MyInput = (props) => {
    return (
        <input {...props} />
    );
};

export default MyInput;
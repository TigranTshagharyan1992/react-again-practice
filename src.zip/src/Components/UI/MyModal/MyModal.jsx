import React from 'react';
import cssClasses from './MyModal.css'

const MyModal = ({children,visible}) => {
console.log(visible);
    let modalClass = "myModal";
    if(visible){
        modalClass = "myModal active";
    }
    return (
        <div className={modalClass}>
            <div className="myModalContent">
                {children}
            </div>
        </div>
    );
};

export default MyModal;